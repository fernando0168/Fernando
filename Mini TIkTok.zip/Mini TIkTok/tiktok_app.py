import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import os
from abc import ABC, abstractmethod
from uuid import uuid4
from typing import List

# ===== DOMAIN CLASSES =====

class User:
    def __init__(self, name: str):
        self.id = str(uuid4())
        self.name = name

class Comment:
    def __init__(self, user: User, content: str):
        self.user = user
        self.content = content

class Reaction(ABC):
    def __init__(self, user: User):
        self.user = user

    @abstractmethod
    def type(self) -> str:
        pass

class Like(Reaction):
    def type(self) -> str:
        return "Like"

class Video:
    def __init__(self, title: str, filepath: str, owner: User):
        self.id = str(uuid4())
        self.title = title
        self.filepath = filepath
        self.owner = owner
        self.reactions: List[Reaction] = []
        self.comments: List[Comment] = []

# ===== INTERFACES =====

class IReactionService(ABC):
    @abstractmethod
    def add_reaction(self, video: Video, reaction: Reaction) -> None:
        pass

class ICommentService(ABC):
    @abstractmethod
    def add_comment(self, video: Video, comment: Comment) -> None:
        pass

class IVideoRepository(ABC):
    @abstractmethod
    def add_video(self, video: Video) -> None:
        pass

    @abstractmethod
    def get_all_videos(self) -> List[Video]:
        pass

# ===== SERVICES =====

class LikeService(IReactionService):
    def add_reaction(self, video: Video, reaction: Reaction) -> None:
        video.reactions.append(reaction)

class CommentService(ICommentService):
    def add_comment(self, video: Video, comment: Comment) -> None:
        video.comments.append(comment)

class InMemoryVideoRepository(IVideoRepository):
    def __init__(self):
        self.videos: List[Video] = []

    def add_video(self, video: Video) -> None:
        self.videos.append(video)

    def get_all_videos(self) -> List[Video]:
        return self.videos

class FeedService:
    def __init__(self, video_repository: IVideoRepository):
        self.video_repository = video_repository

    def list_videos(self) -> List[Video]:
        return self.video_repository.get_all_videos()

# ===== GUI APP =====

class TikTokApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Mini TikTok App")
        self.root.geometry("750x600")
        self.root.configure(bg="#f4f4f4")

        self.user = self.get_user()
        if not self.user:
            root.destroy()
            return

        self.repo = InMemoryVideoRepository()
        self.like_service = LikeService()
        self.comment_service = CommentService()
        self.feed_service = FeedService(self.repo)

        self.create_widgets()

    def get_user(self):
        name = simpledialog.askstring("Bem-vindo!", "Digite seu nome de usuário:")
        if name:
            return User(name)
        else:
            return None

    def create_widgets(self):
        title = tk.Label(self.root, text="🎬 Mini TikTok", font=("Helvetica", 20, "bold"), bg="#f4f4f4", fg="#333")
        title.pack(pady=10)

        user_label = tk.Label(self.root, text=f"Usuário atual: {self.user.name}", font=("Helvetica", 12), bg="#f4f4f4", fg="#555")
        user_label.pack(pady=(0, 10))

        # Frame de ações
        action_frame = tk.Frame(self.root, bg="#f4f4f4")
        action_frame.pack(pady=10)

        btn_style = {"font": ("Helvetica", 10), "bg": "#4CAF50", "fg": "white", "padx": 10, "pady": 5}

        tk.Button(action_frame, text="Postar Vídeo", command=self.post_video, **btn_style).grid(row=0, column=0, padx=5)
        tk.Button(action_frame, text="Atualizar Feed", command=self.refresh_feed, **btn_style).grid(row=0, column=1, padx=5)

        # Lista de vídeos
        self.listbox = tk.Listbox(self.root, width=90, height=15, font=("Courier", 10), bg="white", fg="#333")
        self.listbox.pack(pady=10)

        # Frame de interações
        interaction_frame = tk.Frame(self.root, bg="#f4f4f4")
        interaction_frame.pack(pady=10)

        small_btn = {"font": ("Helvetica", 10), "bg": "#2196F3", "fg": "white", "padx": 10, "pady": 5}

        tk.Button(interaction_frame, text="Abrir Vídeo", command=self.open_video, **small_btn).grid(row=0, column=0, padx=5)
        tk.Button(interaction_frame, text="Curtir", command=self.like_video, **small_btn).grid(row=0, column=1, padx=5)
        tk.Button(interaction_frame, text="Comentar", command=self.comment_video, **small_btn).grid(row=0, column=2, padx=5)
        tk.Button(interaction_frame, text="Ver Detalhes", command=self.show_details, **small_btn).grid(row=0, column=3, padx=5)

    def post_video(self):
        filepath = filedialog.askopenfilename(filetypes=[("Vídeos", "*.mp4 *.avi *.mov")])
        if filepath:
            title = simpledialog.askstring("Título", "Digite o título do vídeo:")
            if title:
                video = Video(title, filepath, self.user)
                self.repo.add_video(video)
                messagebox.showinfo("Sucesso", f"Vídeo '{title}' postado!")
                self.refresh_feed()

    def refresh_feed(self):
        self.listbox.delete(0, tk.END)
        for video in self.feed_service.list_videos():
            display = f"{video.title} | Autor: {video.owner.name} | ❤️ {len(video.reactions)} | 💬 {len(video.comments)}"
            self.listbox.insert(tk.END, display)

    def get_selected_video(self) -> Video:
        index = self.listbox.curselection()
        if not index:
            messagebox.showwarning("Aviso", "Selecione um vídeo.")
            return None
        return self.repo.get_all_videos()[index[0]]

    def open_video(self):
        video = self.get_selected_video()
        if video:
            try:
                if os.name == "nt":
                    os.startfile(video.filepath)
                elif os.name == "posix":
                    os.system(f"xdg-open \"{video.filepath}\"")
                else:
                    messagebox.showinfo("Erro", "Sistema não suportado.")
            except Exception as e:
                messagebox.showerror("Erro", f"Não foi possível abrir: {e}")

    def like_video(self):
        video = self.get_selected_video()
        if video:
            self.like_service.add_reaction(video, Like(self.user))
            self.refresh_feed()

    def comment_video(self):
        video = self.get_selected_video()
        if video:
            comment_text = simpledialog.askstring("Comentário", "Digite seu comentário:")
            if comment_text:
                comment = Comment(self.user, comment_text)
                self.comment_service.add_comment(video, comment)
                self.refresh_feed()

    def show_details(self):
        video = self.get_selected_video()
        if video:
            like_names = [r.user.name for r in video.reactions]
            comment_lines = [f"{c.user.name}: {c.content}" for c in video.comments]

            like_text = "\n".join(like_names) or "Sem curtidas"
            comment_text = "\n".join(comment_lines) or "Sem comentários"

            details = f"🎬 Vídeo: {video.title}\n👤 Por: {video.owner.name}\n\n❤️ Curtidas:\n{like_text}\n\n💬 Comentários:\n{comment_text}"
            messagebox.showinfo("Detalhes do Vídeo", details)

# ===== MAIN =====

if __name__ == "__main__":
    root = tk.Tk()
    app = TikTokApp(root)
    root.mainloop()
